'use strict'

// Set events on page loaded
document.addEventListener('DOMContentLoaded', function () { 
    
});

